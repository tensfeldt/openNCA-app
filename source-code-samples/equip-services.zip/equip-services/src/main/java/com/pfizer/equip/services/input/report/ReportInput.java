package com.pfizer.equip.services.input.report;

import com.pfizer.equip.services.input.library.LibraryInput;

public class ReportInput extends LibraryInput {

}
