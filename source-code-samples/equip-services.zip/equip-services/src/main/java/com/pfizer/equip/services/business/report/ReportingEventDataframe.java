package com.pfizer.equip.services.business.report;

public class ReportingEventDataframe {
   String equipId;
   String id;

   public String getEquipId() {
      return equipId;
   }

   public void setEquipId(String equipId) {
      this.equipId = equipId;
   }

   public String getId() {
      return id;
   }

   public void setId(String id) {
      this.id = id;
   }
}
