package com.pfizer.equip.services.business.api.input;

// an empty interface used to represent any type of input to the compute service
public interface GenericInput {

}
