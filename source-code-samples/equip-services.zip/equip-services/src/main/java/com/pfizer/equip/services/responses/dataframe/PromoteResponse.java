package com.pfizer.equip.services.responses.dataframe;

import com.pfizer.equip.shared.responses.AbstractResponse;

public class PromoteResponse extends AbstractResponse {

}
