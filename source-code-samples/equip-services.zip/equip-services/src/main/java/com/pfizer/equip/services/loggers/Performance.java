package com.pfizer.equip.services.loggers;

/**
 * 
 * Utility class used for performance logging.
 *
 */
public class Performance {

}
