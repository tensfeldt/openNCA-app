package com.pfizer.equip.services.input;

public abstract class AbstractInput {
   
}
