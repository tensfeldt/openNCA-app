package com.pfizer.equip.services.input.search;

public class SearchOrdering {
   private String field;
   private String direction;

   public String getField() {
      return field;
   }

   public String getDirection() {
      return direction;
   }

   public void setField(String field) {
      this.field = field;
   }

   public void setDirection(String direction) {
      this.direction = direction;
   }
}
