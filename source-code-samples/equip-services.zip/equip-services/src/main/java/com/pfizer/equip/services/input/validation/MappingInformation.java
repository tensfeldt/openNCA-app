package com.pfizer.equip.services.input.validation;

public class MappingInformation {
   private String columnName;
   private String columnMappingName;

   public String getColumnName() {
      return columnName;
   }

   public void setColumnName(String columnName) {
      this.columnName = columnName;
   }

   public String getColumnMappingName() {
      return columnMappingName;
   }

   public void setColumnMappingName(String columnMappingName) {
      this.columnMappingName = columnMappingName;
   }

}
