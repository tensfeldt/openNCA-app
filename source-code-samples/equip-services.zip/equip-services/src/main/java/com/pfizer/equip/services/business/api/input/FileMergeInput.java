package com.pfizer.equip.services.business.api.input;

public class FileMergeInput {

}
