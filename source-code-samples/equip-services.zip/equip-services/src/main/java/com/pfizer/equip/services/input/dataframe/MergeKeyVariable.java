package com.pfizer.equip.services.input.dataframe;

public class MergeKeyVariable {
   String variableName;
   
   public MergeKeyVariable(String variableName) {
      this.variableName = variableName;
   }

   public String getVariableName() {
      return variableName;
   }

   public void setVariableName(String variableName) {
      this.variableName = variableName;
   }
}
